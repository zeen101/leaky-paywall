<?php 

/**
* Load the base class
*/
class LP_Free_Transaction extends LP_Transaction {
	
	function __construct()	{
		
	}

	public function createTransaction() 
	{
		
	}

	public function getTransaction() 
	{
		
	}

}